# base.py
# -*- coding: utf-8 -*-
import torch
import torch.nn as nn
from typing import Sequence, Type, List, Dict, Optional, Tuple

class SimpleMLP(nn.Module):
  """
  가장 단순한 MLP:
    - hidden_sizes 길이만큼 Linear 쌓기
    - hidden 활성함수는 전 레이어 공통 적용
    - 출력층 별도 Linear + (옵션) 출력 활성함수
  """
  def __init__(self,
                input_dim: int,
                output_dim: int,
                hidden_layers: list):
      super().__init__()
      self.input_dim = input_dim
      self.output_dim = output_dim
      self.layers = [nn.Linear(self.input_dim, hidden_layers[0]), nn.ReLU() ]

      for layer_id in range(1, len(hidden_layers)):
          self.layers.append(nn.Linear(hidden_layers[layer_id-1], hidden_layers[layer_id]))
          self.layers.append(nn.ReLU())
      self.layers.append(nn.Linear(hidden_layers[-1], output_dim))
      self.model = nn.Sequential(
          *self.layers
      )
  
  def value_function(self,
                      obs: torch.Tensor,
                      params: Optional[Dict[str, torch.Tensor]] = None) -> torch.Tensor:
      """
      A2C/PPO 등 critic이 있는 정책에서만 구현.
      없는 경우 NotImplementedError 발생.
      """
      if not self.has_value_fn:
          raise NotImplementedError("Policy has no value_function.")
      raise NotImplementedError("Subclass with baseline must implement this.")

  def forward(self, state: torch.Tensor) -> torch.Tensor:
      output = self.model(state)
      return output

class BasePolicy(nn.Module):
  """
  알고리즘(ProMP 등)이 기대하는 최소 정책 API를 한 클래스에 통합.

  핵심 원칙
    - 분포 타입(가우시안/카테고리/혼합 등)에는 전혀 의존하지 않음.
    - 알고리즘은 오직 log_prob(obs, actions, params)만 호출.
    - 샘플러는 act(obs) 호출 시 agent_infos['logp'](샘플 시점의 log_prob)를 반드시 기록.

  서브클래스가 구현해야 할 것
    - act(self, obs, deterministic=False) -> (actions, agent_infos[필수:'logp'])
    - log_prob(self, obs, actions, params=None) -> [B] 텐서
    - (선택) _functional_forward(self, obs, params): inner-loop로 적응한 params로 forward 하고 싶을 때
    - (필요 시) forward(...) 재정의 (분포/출력 방식이 다르면)

  편의 기능
    - 기본 MLP 백본(self.net)을 옵션으로 제공(build_backbone=True). 필요 없으면 무시하거나 False로 끄면 됨.
    - get_action / get_actions_all_tasks: 기존 코드와의 이름 호환용 래퍼(선택 구현).
  """

  def __init__(self,
               policy,
                gamma: float = 0.99,
                has_value_fn: bool = False):
      super().__init__()
      self.policy = policy
      self.gamma = gamma
      self.has_value_fn = has_value_fn  # [NEW]

  # ---------------------- 최소 API (알고리즘이 의존) ----------------------
  torch.no_grad()
  def get_action(self,
                  observation: torch.Tensor,
                  task: int = 0,
                  deterministic: bool = False) -> Tuple[torch.Tensor, Dict[str, torch.Tensor]]:
    """
    기존 코드 호환을 위해 제공하는 래퍼. 내부적으로 act(...)를 호출한다.
    - task 인자는 시그니처 호환용일 뿐, 기본 BasePolicy에서는 사용하지 않는다.
    """
    raise NotImplementedError
  
  def log_prob(self,
                obs: torch.Tensor,
                actions: torch.Tensor,
                params: Optional[Dict[str, torch.Tensor]] = None) -> torch.Tensor:
      """
      Args:
        obs: [B, obs_dim]
        actions: [B, out_dim]
        params: state_dict 형태(선택). 주어지면 해당 파라미터로 log_prob 계산.
      Returns:
        [B] 텐서 (각 샘플의 log_prob)
      Note:
        - 분포 타입에 상관없이 로그확률만 정확히 반환하면 알고리즘 쪽은 그대로 작동한다.
      """
      raise NotImplementedError

  