# Meta_Gaussian.py  (수정본)
import torch
from torch.distributions.independent import Independent
from typing import List, Dict, Optional, Tuple
from AIIS_META.Utils.utils import *
from .Gaussian import GaussianPolicy  # 기존 구현 사용

class MetaGaussianPolicy(GaussianPolicy):
    def __init__(self, meta_batch_size: int, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.meta_batch_size = meta_batch_size
        self._pre_update_mode = True
        print("gaussian policy ready")

    def set_pre_update_mode(self, flag: bool = True):
        self._pre_update_mode = flag
        if flag:
            self.policies_params_vals = None

    # -----------------------------------------------------------
    # 핵심: 하나의 observation에 대해 out_dim 개수만큼의 mean/std/action/logp 정보를 반환
    # -----------------------------------------------------------
    @torch.no_grad()
    def get_action(self,
                   observation: torch.Tensor,
                   deterministic: bool = False
                   ) -> Tuple[torch.Tensor, Dict[str, object]]:
        """
        Args:
          observation: [obs_dim] 또는 [1, obs_dim] (단일 관측)
          task: (post-update 모드일 때) 어느 태스크의 파라미터를 쓸지
          deterministic: True면 샘플 대신 mean 사용

        Returns:
          actions: tensor [out_dim]
          info: dict {
            "mean": tensor [out_dim],
            "std": tensor [out_dim],
            "logp_total": scalar tensor,
            "logp_per_dim": tensor [out_dim],
            "per_dim": list(len=out_dim) of dict(mean, std, action, logp)
          }
        """
        # 입력 정리: single observation 형태로 맞춤
        
        # 분포 선택: pre/post update
        dist = self.distribution(observation)   # Independent(Normal(mean,[1,out_dim]), 1)

        # action (batched [1, out_dim]) -> squeeze -> [out_dim]
        if deterministic:
            actions_b = dist.mean                    # [1, out_dim]
        else:
            # .rsample() 대신 .sample() 사용해도 됨. rsample는 reparam available
            try:
                actions_b = dist.rsample()
            except Exception:
                actions_b = dist.sample()

        actions = actions_b.squeeze(0)               # [out_dim]

        # per-dim statistics (still batched shape [1, out_dim], then squeeze)
        mean_b = dist.mean                           # [1, out_dim]
        std_b = dist.base_dist.scale                 # [1, out_dim]
        mean = mean_b.squeeze(0)                     # [out_dim]
        std = std_b.squeeze(0)                       # [out_dim]

        # per-dim structured info (you can keep tensors or convert to python scalars .item())
        per_dim={"mean": mean,              # tensor scalar
                "std": std,                # tensor scalar
                "action": [action for action in actions],         # tensor scalar
                }
 
        return actions, per_dim
